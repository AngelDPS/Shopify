from logging import getLogger
from gql import Client, gql
from gql.transport.requests import RequestsHTTPTransport
from gql.transport.exceptions import (
    TransportQueryError,
    TransportServerError
)
from models.producto import MproductInput, MproductVariantInput
from models.coleccion import McollectionInput
from models.misc import McreateMediaInput
from libs.util import get_parameter

logger = getLogger(__name__)

try:
    # TODO: Aquí se obtiene el parámetro de configuración para el
    # identificador de la tienda en Shopify.
    SHOP = get_parameter('SHOPIFY_SHOP')
except KeyError:
    logger.exception("No se encontró en la variable de ambiente 'SHOPIFY_SHOP'"
                     " el identificador del URL de la tienda de shopify.")
    raise
try:
    # TODO: Aquí se obtiene el parámetro de configuración para el
    # token de acceso de la API de administrador en Shopify.
    ACCESS_TOKEN = get_parameter('SHOPIFY_ACCESS_TOKEN')
except KeyError:
    logger.exception("No se encontró en la variable de ambiente "
                     "'SHOPIFY_ACCESS_TOKEN' el token de acceso para la "
                     "aplicación admin de la tienda de shopify.")
    raise

API_VERSION: str = "2023-04"
# TODO: Aquí se usa el parámetro de configuración para el
# identificador de la tienda en Shopify.
URL = f"https://{SHOP}.myshopify.com/admin/api/{API_VERSION}/graphql.json"

# TODO: Aquí se usa el parámetro de configuración para el
# token de acceso de la API de administrador en Shopify.
transport = RequestsHTTPTransport(
    URL,
    headers={'X-Shopify-Access-Token': ACCESS_TOKEN},
    retries=3,
    timeout=(3.05, 5)
)
cliente = Client(transport=transport)


def execute(request_str: str,
            # operacion: str = None,
            variables: dict = None
            ) -> dict:
    """Envía una consulta de GraphQL usando el transporte inicializado en
    la instancia.

    Args:
        request_str (str): Consulta de graphQL
        variables (dict, optional): Variables que 'request' puede utilizar
        para realizar la consulta. Defaults to None.
        operacion (str, optional): Si 'request' esta compuesta de varias
        operaciones posibles. 'operacion' selecciona la que se va a
        utilizar. Defaults to None.

    Returns:
        dict: Json deseralizado recibido como respuesta a la consulta.
    """
    logger.debug(f'{variables = }')
    try:
        respuesta = cliente.execute(
            gql(request_str),
            variable_values=variables  # ,
            # operation_name=operacion
        )
        logger.debug(f"{respuesta = }")
    except TransportQueryError as err:
        logger.exception(
            "Hubo un problema con la consulta, "
            f"el servidor retornó un error {err}."
        )
        raise
    except TransportServerError as err:
        logger.exception(
            "Hubo un problema con el servidor, "
            f"retornó un código {err.code}"
        )
        raise
    except Exception as err:
        logger.exception(
            f"Se encontró un error inesperado.\n{type(err)}\n{err}"
        )
        raise
    else:
        if respuesta[list(respuesta)[0]].get("userErrors"):
            msg = ("No fue posible realizar la operación:\n"
                   f"{respuesta[list(respuesta)[0]]['userErrors']}")
            logger.exception(msg)
            raise RuntimeError(msg)
    return respuesta


def obtenerGidTienda(nombre: str) -> str:
    try:
        return execute(
            """
            query Tienda($nombre: String) {
                locations(first: 1, query: $nombre) {
                    nodes {
                        id
                    }
                }
            }
            """,
            variables={"nombre": f"name:{nombre}"}
        )['locations']['nodes'][0]['id']
    except Exception:
        logger.exception("Error al consultar el GID de sucursal.")
        raise


def obtenerGidPublicaciones():
    pubIDs = [i["id"] for i in
              execute(
        """
                query obtenerPublicaciones {
                    publications(first: 2) {
                        nodes {
                            id
                        }
                    }
                }
                """
    )['publications']['nodes']]
    return pubIDs


def publicarRecurso(GID: str, pubIDs: list[str]):
    try:
        execute(
            """
            mutation publicar($id: ID!, $input: [PublicationInput!]!) {
                publishablePublish(id: $id, input: $input) {
                    userErrors {
                        message
                    }
                }
            }
            """,
            variables={
                'id': GID,
                'input': [{"publicationId": id}
                          for id in pubIDs]
            }
        )
        logger.info("Publicación exitosa del recurso.")
    except Exception:
        logger.exception("No se pudo publicar el recurso.")
        raise


def crearProducto(productInput: MproductInput,
                  mediaInput: list[McreateMediaInput]) -> str:
    try:
        respuesta = execute(
            """
            mutation crearProducto($input: ProductInput!,
                    $media: [CreateMediaInput!]){
                productCreate(input: $input, media: $media) {
                    product {
                        id
                        variants(first: 1) {
                            nodes {
                                id
                                inventoryItem {
                                    id
                                }
                            }
                        }
                        media(first:10) {
                            nodes {
                                ... on MediaImage {
                                    id
                                }
                            }
                        }
                    }
                    userErrors {
                        message
                    }
                }
            }
            """,
            variables={'input': productInput.dict(exclude_none=True),
                       'media': [mInput.dict(exclude_none=True)
                                 for mInput in mediaInput]}
        )
        logger.info("Producto creado exitosamente en Shopify.")
    except Exception:
        logger.exception("Error encontrado al crear el producto en Shopify.")
        raise
    try:
        shopifyGID = {
            'producto': respuesta['productCreate']['product']['id'],
            'variante': {
                'id': (respuesta['productCreate']['product']
                       ['variants']['nodes'][0]['id']),
                'inventario': (respuesta['productCreate']['product']
                               ['variants']['nodes'][0]['inventoryItem']
                               ['id'])
            },
            'imagenes': {
                imInput.originalSource.fname: imNodes['id']
                for imInput, imNodes in zip(
                    mediaInput,
                    respuesta['productCreate']['product']['media']['nodes']
                )
            }
        }
        return shopifyGID
    except (KeyError, IndexError):
        logger.exception("Formato inesperado de respuesta para la creación "
                         "del producto.")
        raise


def modificarInventario(delta: int, invId: str, locId: str):
    try:
        reason = "restock" if delta > 0 else "shrinkage"
        execute(
            """
                mutation ajustarInventarios(
                    $delta: Int!,
                    $inventoryItemId: ID!,
                    $locationId: ID!,
                    $name: String!,
                    $reason: String!
                ) {
                    inventoryAdjustQuantities(input: {
                        changes: [
                            {
                                delta: $delta,
                                inventoryItemId: $inventoryItemId,
                                locationId: $locationId
                            }
                        ],
                        name: $name,
                        reason: $reason
                        }){
                        userErrors {
                            message
                        }
                    }
                }
                """,
            variables={
                "delta": delta,
                "name": "available",
                "reason": reason,
                "inventoryItemId": invId,
                "locationId": locId
            }
        )
        logger.info("Inventario modificado exitosamente.")
    except Exception:
        logger.exception("Ocurrió un error al tratar de modificar el "
                         "inventario.")
        raise


def modificarVarianteProducto(variantInput: MproductVariantInput):
    try:
        execute(
            """
            mutation modificarVarianteProducto(
                    $input: ProductVariantInput!
                ) {
                productVariantUpdate(input: $input) {
                    userErrors {
                        message
                    }
                }
            }
            """,
            variables={'input': variantInput.dict(exclude_none=True,
                                                  exclude_unset=True)}
        )
        logger.info("Variante modificado exitosamente.")
    except Exception:
        logger.exception("Ocurrió un error al tratar de modificar la "
                         "variante del producto.")
        raise


def modificarProducto(productInput: MproductInput):
    try:
        execute(
            """
            mutation modificarProducto($input: ProductInput!) {
                productUpdate(input: $input) {
                    userErrors {
                        message
                    }
                }
            }
            """,
            variables={'input': productInput.dict(exclude_none=True,
                                                  exclude_unset=True)}
        )
        logger.info("Producto modificado exitosamente.")
    except Exception:
        logger.exception("Ocurrió un error al tratar de modificar el "
                         "producto.")
        raise


def consultarProducto(nombre: str):
    try:
        respuesta = execute(
            """
            query productoPorNombre($nombre: String) {
                products(first: 1, query: $nombre) {
                    nodes {
                        id
                        variants(first: 1) {
                            nodes {
                                id
                                inventoryItem {
                                    id
                                    inventoryLevels(first: 10) {
                                        nodes {
                                            location {
                                                name
                                                id
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            """
        )
    except Exception:
        logger.exception("Hubo un problema al consultar el producto en "
                         "Shopify.")
        raise
    try:
        shopifyGID = {
            'producto': respuesta['products']['nodes'][0]['id'],
            'variante': {
                'id': (respuesta['products']['nodes'][0]
                       ['variants']['nodes'][0]['id']),
                'inventario': (respuesta['products']['nodes'][0]
                               ['variants']['nodes'][0]['inventoryItem']
                               ['id'])
            }
        }
        locations = {
            loc['name']: loc['id'] for loc in (
                respuesta['products']['nodes'][0]['variants']['nodes'][0]
                ['inventoryItem']['inventory']
            )
        }
        return (shopifyGID, locations)
    except (KeyError, IndexError):
        logger.exception("Formato inesperado de respuesta para la creación "
                         "del producto.")
        raise


def obtenerGidColeccion(nombre: str) -> str:
    try:
        return execute(
            """
            query coleccionPorNombre($nombre: String) {
                collections(query: $nombre, first: 1) {
                    nodes {
                    id
                    }
                }
            }
            """,
            variables={"nombre": f"title:{nombre}"}
        )['collections']['nodes'][0]['id']
    except IndexError:
        logger.warning(f"Colección con nombre '{nombre}' no encontrada.")
        raise
    except Exception:
        logger.exception("Error al consultar el GID de colección.")
        raise


def crearColeccion(collectionInput: McollectionInput) -> str:
    try:
        return execute(
            """
            mutation crearColeccion($input: CollectionInput!) {
                collectionCreate(input: $input) {
                    collection {
                        id
                    }
                    userErrors {
                        message
                    }
                }
            }
            """,
            variables={
                'input': collectionInput.dict(exclude_none=True)
            }
        )["collectionCreate"]["collection"]["id"]
    except Exception:
        logger.exception("Error encontrado al crear la colección en Shopify")
        raise


def modificarColeccion(collectionInput: McollectionInput):
    execute(
        """
        mutation modificarColeccion($input: CollectionInput!) {
            collectionUpdate(input: $input) {
                userErrors {
                message
                }
            }
        }
        """,
        variables={'input': collectionInput.dict(exclude_none=True,
                                                 exclude_unset=True)},
    )


def obtenerGidImagen(fname: str) -> str:
    try:
        return execute(
            """
            query ImageFileId($filename: String) {
                files(first: 10, query: $filename) {
                    nodes {
                        ... on MediaImage {
                            id
                        }
                    }
                }
            }
            """,
            variables={'filename': f'filename:{fname}'}
        )['files']['nodes'][0]['id']
    except IndexError:
        logger.warning(f"Archivo de imagen con nombre '{fname}' "
                       "no encontrado en Shopify.")
        raise
    except Exception:
        logger.exception("Error al consultar el GID de colección.")
        raise


def cargarImagen(url: str) -> str:
    try:
        return execute(
            """
            mutation cargarImagen($input: FileCreateInput!) {
                fileCreate(files: [$input]) {
                    files {
                        ... on MediaImage {
                            id
                        }
                    }
                }
            }
            """,
            variables={"input": {
                "contentType": "IMAGE",
                "originalSource": url
            }}
        )['fileCreate']['files'][0]['id']
    except Exception:
        logger.exception("Error encontrado al cargar la imagen en Shopify")
        raise


def anexarImagenArticulo(productId: str, mediaInput: list[McreateMediaInput]):
    try:
        respuesta = execute(
            """
            mutation anexarImagen($productId: ID!,
                                  $media: [CreateMediaInput!]!) {
                productCreateMedia(productId: $productId, media: $media) {
                    media {
                        ... on MediaImage{
                            id
                        }
                    }
                    mediaUserErrors {
                        message
                    }
                }
            }
            """,
            variables={'productId': productId,
                       'media': [mInput.dict(exclude_none=True)
                                 for mInput in mediaInput]}
        )
        if respuesta['productCreateMedia']['mediaUserErrors']:
            msg = (f"{respuesta['productCreateMedia']['mediaUserErrors']}")
            logger.exception(msg)
            raise RuntimeError(msg)
        logger.info("Imágenes anexadas correctamente.")
    except Exception:
        logger.exception("Hubo un problema anexando las imágenes")
        raise
    try:
        shopifyGID = {
            'imagenes': {
                imInput.originalSource.fname: imNodes['id']
                for imInput, imNodes in zip(
                    mediaInput,
                    respuesta['productCreateMedia']['media']
                )
            }
        }
        return shopifyGID
    except (KeyError, IndexError):
        logger.exception("Formato inesperado de respuesta para la creación "
                         "del producto.")
        raise


def eliminarImagenArticulo(productId: str, mediaIds: list[str]):
    try:
        respuesta = execute(
            """
            mutation removerImagen($productId: ID!, $mediaIds: [ID!]!) {
                productDeleteMedia(productId: $productId,
                                   mediaIds: $mediaIds) {
                    mediaUserErrors {
                        message
                    }
                }
            }
            """,
            variables={'productId': productId, 'mediaIds': mediaIds}
        )
        if respuesta['productDeleteMedia']['mediaUserErrors']:
            msg = (f"{respuesta['productDeleteMedia']['mediaUserErrors']}")
            logger.exception(msg)
            raise RuntimeError(msg)
        logger.info("Imágenes eliminadas correctamente.")
    except Exception:
        logger.exception("Hubo un problema eliminando las imágenes")
        raise
